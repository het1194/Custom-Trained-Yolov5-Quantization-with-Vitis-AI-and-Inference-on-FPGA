import numpy as np
import cv2
import vart
import xir
import argparse
import os
import time
import math
import log

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def xywh2xyxy(x):
    y = np.copy(x)
    y[..., 0] = x[..., 0] - x[..., 2] / 2
    y[..., 1] = x[..., 1] - x[..., 3] / 2
    y[..., 2] = x[..., 0] + x[..., 2] / 2
    y[..., 3] = x[..., 1] + x[..., 3] / 2
    return y

def non_max_suppression_numpy(prediction, conf_thres=0.01, iou_thres=0.45):
    nc = prediction.shape[2] - 5
    xc = prediction[..., 4] > conf_thres

    output = [np.zeros((0, 6))] * prediction.shape[0]
    for xi, x in enumerate(prediction):
        x = x[xc[xi]]
        if not x.shape[0]: continue

        x[:, 5:] *= x[:, 4:5]
        box = xywh2xyxy(x[:, :4])
        i, j = np.where(x[:, 5:] > conf_thres)
        x = np.concatenate((box[i], x[i, j + 5, None], j[:, None].astype(float)), 1)
        if not x.shape[0]: continue

        boxes = x[:, :4]; scores = x[:, 4]; classes = x[:, 5]
        unique_classes = np.unique(classes)
        final_indices = []

        for c in unique_classes:
            cls_mask = (classes == c)
            cls_boxes = boxes[cls_mask]; cls_scores = scores[cls_mask]
            order = cls_scores.argsort()[::-1]
            x1 = cls_boxes[:, 0]; y1 = cls_boxes[:, 1]; x2 = cls_boxes[:, 2]; y2 = cls_boxes[:, 3]
            areas = (x2 - x1 + 1) * (y2 - y1 + 1)
            
            keep = []
            while order.size > 0:
                i = order[0]; keep.append(i)
                xx1 = np.maximum(x1[i], x1[order[1:]]); yy1 = np.maximum(y1[i], y1[order[1:]])
                xx2 = np.minimum(x2[i], x2[order[1:]]); yy2 = np.minimum(y2[i], y2[order[1:]])
                w = np.maximum(0.0, xx2 - xx1 + 1); h = np.maximum(0.0, yy2 - yy1 + 1)
                inter = w * h
                ovr = inter / (areas[i] + areas[order[1:]] - inter)
                inds = np.where(ovr <= iou_thres)[0]
                order = order[inds + 1]
            
            original_indices = np.where(cls_mask)[0][keep]
            final_indices.extend(original_indices)
        output[xi] = x[final_indices]
    return output

def scale_coords_numpy(img1_shape, coords, img0_shape):
    h0, w0 = img0_shape[:2]; h1, w1 = img1_shape[:2]
    gain_w = w0 / w1; gain_h = h0 / h1
    coords[:, [0, 2]] *= gain_w; coords[:, [1, 3]] *= gain_h
    coords[:, [0, 2]] = np.clip(coords[:, [0, 2]], 0, w0)
    coords[:, [1, 3]] = np.clip(coords[:, [1, 3]], 0, h0)
    return coords

def unflip_coords(boxes, model_width):
    new_boxes = boxes.copy()
    new_boxes[:, 0] = model_width - boxes[:, 2]
    new_boxes[:, 2] = model_width - boxes[:, 0]
    return new_boxes

def plot_one_box_numpy(x, img, color=None, label=None, line_thickness=3):
    tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    color = color or [np.random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

class PostProcessNumpy:
    def __init__(self):
        self.nc = 1; self.no = self.nc + 5; self.nl = 3; self.na = 3
        self.strides = np.array([8., 16., 32.])
        self.anchors = np.array([
            [[1.25, 1.625], [2.0, 3.75], [4.125, 2.875]],
            [[1.875, 3.8125], [3.875, 2.8125], [3.6875, 7.4375]],
            [[3.625, 2.8125], [4.875, 6.1875], [11.65625, 10.1875]]
        ])
    def __call__(self, x): 
        z = [] 
        for i in range(self.nl):
            bs, _, ny, nx = x[i].shape
            x[i] = x[i].reshape(bs, self.na, self.no, ny, nx).transpose(0, 1, 3, 4, 2)
            grid_y, grid_x = np.meshgrid(np.arange(ny), np.arange(nx), indexing='ij')
            grid = np.stack((grid_x, grid_y), 2).reshape(1, 1, ny, nx, 2)
            anchor_grid = (self.anchors[i] * self.strides[i]).reshape(1, self.na, 1, 1, 2)
            y = sigmoid(x[i])
            y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + grid) * self.strides[i]
            y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * anchor_grid
            z.append(y.reshape(bs, -1, self.no))
        return np.concatenate(z, axis=1)

def preprocess_image(img, target_shape):
    th, tw = target_shape
    img_resized = cv2.resize(img, (tw, th), interpolation=cv2.INTER_LINEAR) 
    image_data = img_resized.astype(np.float32) / 255.0

    image_data = np.expand_dims(image_data, axis=0)
    return image_data

def run_dpu_inference(runner, frame_to_process, input_height, input_width, post_processor, use_tta=False):
    preprocessed_image = preprocess_image(frame_to_process, (input_height, input_width))
    input_data = [preprocessed_image]
    output_data = [np.empty(tuple(t.dims), dtype=np.float32) for t in runner.get_output_tensors()]
    job_id = runner.execute_async(input_data, output_data)
    runner.wait(job_id)
    outputs_for_post = [np.transpose(raw, (0, 3, 1, 2)) for raw in output_data]
    predictions = post_processor(outputs_for_post)

    if use_tta:
        frame_flipped = cv2.flip(frame_to_process, 1)
        preprocessed_flipped = preprocess_image(frame_flipped, (input_height, input_width))
        input_data_flipped = [preprocessed_flipped]
        output_data_flipped = [np.empty(tuple(t.dims), dtype=np.float32) for t in runner.get_output_tensors()]
        job_id_flipped = runner.execute_async(input_data_flipped, output_data_flipped)
        runner.wait(job_id_flipped)
        outputs_flipped = [np.transpose(raw, (0, 3, 1, 2)) for raw in output_data_flipped]
        predictions_flipped = post_processor(outputs_flipped)
        predictions_flipped[..., 0] = input_width - predictions_flipped[..., 0]
        predictions = np.concatenate((predictions, predictions_flipped), axis=1)
    return predictions

def run_camera_inference(xmodel_path, conf_threshold, frame_skip, color_mode, use_tta):
    print("Loading XMODEL and creating DPU runner...")
    graph = xir.Graph.deserialize(xmodel_path)
    subgraphs = graph.get_root_subgraph().toposort_child_subgraph()
    dpu_subgraph = next((s for s in subgraphs if "DPU" in s.get_attr("device")), None)
    if dpu_subgraph is None: 
        print("Error: No DPU subgraph found.")
        return
    
    runner = vart.Runner.create_runner(dpu_subgraph, "run")
    input_tensors = runner.get_input_tensors()
    input_height = input_tensors[0].dims[1]
    input_width = input_tensors[0].dims[2]
    post_processor = PostProcessNumpy()

    # Open the camera
    cap = cv2.VideoCapture(0)  # 0 for the first camera (use 1, 2, etc. for additional cameras)
    if not cap.isOpened(): 
        print("Error: Could not open the camera.")
        del runner
        return

    frame_count = 0
    total_fps = 0
    last_known_detections = []

    while cap.isOpened():
        ret, original_frame = cap.read()
        if not ret: 
            print("\nError: Failed to capture image from camera.")
            break
        
        loop_start_time = time.time()
        run_detection_this_frame = (frame_count % frame_skip == 0)

        if run_detection_this_frame:
            frame_to_process = cv2.cvtColor(original_frame, cv2.COLOR_BGR2RGB) if color_mode == 'rgb' else original_frame
            mode_str = "RGB" if color_mode == 'rgb' else "BGR"

            predictions = run_dpu_inference(runner, frame_to_process, input_height, input_width, post_processor, use_tta)
            max_obj_conf = np.max(predictions[..., 4])
            detections = non_max_suppression_numpy(predictions, conf_thres=conf_threshold, iou_thres=0.45)[0]

            scaled_detections = []
            detections_to_log = None

            if detections is not None and len(detections):
                original_scores = detections[:, 4]
                multiplied_scores = np.minimum(original_scores * 1.0, 1.0)

                valid_mask = (multiplied_scores > 0.1)

                valid_detections = detections[valid_mask]
                valid_multiplied_scores = multiplied_scores[valid_mask]

                detections_to_log = valid_detections

                if len(valid_detections):
                    scaled_coords = scale_coords_numpy((input_height, input_width), valid_detections[:, :4], original_frame.shape[:2]).round()
                    for i, (*xyxy, conf, cls) in enumerate(valid_detections):
                        scaled_detections.append((scaled_coords[i], valid_multiplied_scores[i], cls))

            log.print_frame_log(frame_count + 1, 0, mode_str, use_tta,
                                max_obj_conf, detections_to_log, 0.1)
            last_known_detections = scaled_detections

        if len(last_known_detections) > 0:
            for (xyxy, conf_x, cls) in last_known_detections:
                label = f'Fire {conf_x:.2f}'
                plot_one_box_numpy(xyxy, original_frame, label=label, color=[0, 0, 255])

        loop_end_time = time.time()
        frame_fps = 1 / (loop_end_time - loop_start_time + 1e-6)
        total_fps += frame_fps
        cv2.putText(original_frame, f"FPS: {frame_fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

        cv2.imshow("Camera Feed", original_frame)  # Display the frame with detections

        if cv2.waitKey(1) & 0xFF == ord('q'):  # Exit on 'q' key press
            break

        frame_count += 1

    cap.release()
    cv2.destroyAllWindows()
    del runner

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='YOLOv5 Camera Inference on VART')
    parser._action_groups.pop()
    required = parser.add_argument_group('required arguments')
    optional = parser.add_argument_group('optional arguments')

    required.add_argument('--model', type=str, required=True, help='Path to the xmodel file')
    required.add_argument('--color_mode', type=str, required=True, choices=['rgb', 'bgr'],
                             help='Color mode the model was trained/quantized on (rgb or bgr)')

    optional.add_argument('--conf_thres', type=float, default=0.01, 
                             help='Confidence threshold') 
    optional.add_argument('--frame_skip', type=int, default=5, 
                             help='Number of frames to skip between detections')
    optional.add_argument('--tta', action='store_true', help='Enable Test-Time Augmentation')
    
    args = parser.parse_args()

    if not os.path.isfile(args.model): 
        print(f"Error: Model not found at {args.model}")
        exit()

    run_camera_inference(
        args.model, 
        args.conf_thres, 
        args.frame_skip,
        args.color_mode,
        args.tta
    )