import time
import numpy as np

def print_header(video_path, w, h, fps, total, in_w, in_h, out_path, log_conf_thres, skip, color, tta):
    print(f"Processing video: {video_path}")
    print(f"Original Resolution: {w}x{h}, FPS: {fps}, Total Frames: {total}")
    print(f"DPU Input Size: {in_w}x{in_h} (Stretching)")
    print(f"Saving output to: {out_path}")
    print(f"Confidence Threshold: {log_conf_thres}")
    print(f"Frame Skip: Running detection 1 of every {skip} frames.")
    print("\n--- STARTING INFERENCE LOG ---")

def print_frame_log(frame_num, total_frames, mode, tta, max_conf, detections, log_conf_thres):
    print(f"\n--- Detecting on Frame {frame_num}/{total_frames} ---")
    num_detections = len(detections) if detections is not None else 0

    if num_detections > 0:
        actual_scores = detections[:, 4]
        conf_x = np.minimum(actual_scores, 1.0)
        max_conf_x = np.max(conf_x)

        print(f"Confidence: {max_conf_x:.4f}")
    else:
        print("Confidence: 0.0000")

    print(f"Found {num_detections} objects")

def print_summary(frame_count, total_fps, output_path):
    if frame_count > 0:
        avg_fps = total_fps / frame_count
        print(f"\nProcessing finished.")
    else:
        print("\nProcessing finished. No frames were processed.")

    print("Resources released.")
    print(f"Output video saved to: {output_path}")
