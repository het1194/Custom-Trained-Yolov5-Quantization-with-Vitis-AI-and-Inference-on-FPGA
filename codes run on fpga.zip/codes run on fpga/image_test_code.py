import numpy as np
import cv2
import vart
import xir
import argparse
import os
import time
import math

def sigmoid(x):
    """Sigmoid activation function in NumPy."""
    return 1 / (1 + np.exp(-x))

def xywh2xyxy(x):
    """Converts (center_x, center_y, width, height) to (x1, y1, x2, y2)."""
    y = np.copy(x)
    y[..., 0] = x[..., 0] - x[..., 2] / 2  # top left x
    y[..., 1] = x[..., 1] - x[..., 3] / 2  # top left y
    y[..., 2] = x[..., 0] + x[..., 2] / 2  # bottom right x
    y[..., 3] = x[..., 1] + x[..., 3] / 2  # bottom right y
    return y

def non_max_suppression_numpy(prediction, conf_thres=0.01, iou_thres=0.45):
    """
    Performs Non-Maximum Suppression (NMS) on inference results using only NumPy.
    Returns:
         list of detections, where each detection is:
         [x1, y1, x2, y2, confidence, class_id]
    """
    nc = prediction.shape[2] - 5  # classes
    xc = prediction[..., 4] > conf_thres  

    output = [np.zeros((0, 6))] * prediction.shape[0]
    for xi, x in enumerate(prediction): 
        x = x[xc[xi]]  

        if not x.shape[0]:
            continue

        x[:, 5:] *= x[:, 4:5] 
        box = xywh2xyxy(x[:, :4])

        i, j = np.where(x[:, 5:] > conf_thres)
        x = np.concatenate((box[i], x[i, j + 5, None], j[:, None].astype(float)), 1)
        
        if not x.shape[0]:
            continue


        boxes = x[:, :4]
        scores = x[:, 4]
        classes = x[:, 5]
        
        unique_classes = np.unique(classes)
        final_indices = []

        for c in unique_classes:
            cls_mask = (classes == c)
            cls_boxes = boxes[cls_mask]
            cls_scores = scores[cls_mask]
            
           
            order = cls_scores.argsort()[::-1]
            
            x1 = cls_boxes[:, 0]
            y1 = cls_boxes[:, 1]
            x2 = cls_boxes[:, 2]
            y2 = cls_boxes[:, 3]
            areas = (x2 - x1 + 1) * (y2 - y1 + 1)
            
            keep = []
            while order.size > 0:
                i = order[0]
                keep.append(i)
                
                xx1 = np.maximum(x1[i], x1[order[1:]])
                yy1 = np.maximum(y1[i], y1[order[1:]])
                xx2 = np.minimum(x2[i], x2[order[1:]])
                yy2 = np.minimum(y2[i], y2[order[1:]])

                w = np.maximum(0.0, xx2 - xx1 + 1)
                h = np.maximum(0.0, yy2 - yy1 + 1)
                inter = w * h
                
                ovr = inter / (areas[i] + areas[order[1:]] - inter)

                inds = np.where(ovr <= iou_thres)[0]
                order = order[inds + 1]
            

            original_indices = np.where(cls_mask)[0][keep]
            final_indices.extend(original_indices)

        output[xi] = x[final_indices]


    return output

def scale_coords_numpy(img1_shape, coords, img0_shape):
    """Rescales coords (xyxy) from img1_shape to img0_shape."""
    gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])  
    pad = (img1_shape[1] - img0_shape[1] * gain) / 2, (img1_shape[0] - img0_shape[0] * gain) / 2 

    coords[:, [0, 2]] -= pad[0]  
    coords[:, [1, 3]] -= pad[1]  
    coords[:, :4] /= gain


    coords[:, [0, 2]] = np.clip(coords[:, [0, 2]], 0, img0_shape[1])  
    coords[:, [1, 3]] = np.clip(coords[:, [1, 3]], 0, img0_shape[0]) 
    return coords

def plot_one_box_numpy(x, img, color=None, label=None, line_thickness=3):
    """Plots one bounding box on image img."""
    tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  
    color = color or [np.random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

class PostProcessNumpy:
    def __init__(self):
        self.nc = 1  
        self.no = self.nc + 5
        self.nl = 3 
        self.na = 3 
        self.strides = np.array([8., 16., 32.])
        self.anchors = np.array([
            [[1.25, 1.625], [2.0, 3.75], [4.125, 2.875]],
            [[1.875, 3.8125], [3.875, 2.8125], [3.6875, 7.4375]],
            [[3.625, 2.8125], [4.875, 6.1875], [11.65625, 10.1875]]
        ])


    def __call__(self, x):
        z = [] 
        for i in range(self.nl):
            bs, _, ny, nx = x[i].shape
    
            x[i] = x[i].reshape(bs, self.na, self.no, ny, nx).transpose(0, 1, 3, 4, 2)

            grid_y, grid_x = np.meshgrid(np.arange(ny), np.arange(nx), indexing='ij')
            grid = np.stack((grid_x, grid_y), 2).reshape(1, 1, ny, nx, 2)
            anchor_grid = (self.anchors[i] * self.strides[i]).reshape(1, self.na, 1, 1, 2)

            y = sigmoid(x[i])
            y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + grid) * self.strides[i]  # xy
            y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * anchor_grid  # wh
            
            z.append(y.reshape(bs, -1, self.no))
            
        return np.concatenate(z, axis=1)

def preprocess_image(img, target_shape):
    h, w, _ = img.shape
    th, tw = target_shape
    scale = min(th / h, tw / w)
    
    nh, nw = int(h * scale), int(w * scale)
    img_resized = cv2.resize(img, (nw, nh))

    img_padded = np.full(shape=[th, tw, 3], fill_value=114, dtype=np.uint8)
    dw, dh = (tw - nw) // 2, (th - nh) // 2
    img_padded[dh:nh+dh, dw:nw+dw, :] = img_resized

    image_data = img_padded.astype(np.float32) / 255.0
    image_data = np.transpose(image_data, (2, 0, 1))
    image_data = np.expand_dims(image_data, axis=0)
    
    return image_data

def run_inference(xmodel_path, image_path):
    original_image = cv2.imread(image_path)
    if original_image is None:
        print(f"Error: Could not read image at {image_path}")
        return

    image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
    
    print("Loading XMODEL and creating DPU runner...")
    graph = xir.Graph.deserialize(xmodel_path)
    subgraphs = graph.get_root_subgraph().toposort_child_subgraph()
    dpu_subgraph = next((s for s in subgraphs if "DPU" in s.get_attr("device")), None)
    
    if dpu_subgraph is None:
        print("Error: No DPU subgraph found in the model.")
        return

    runner = vart.Runner.create_runner(dpu_subgraph, "run")

    input_tensors = runner.get_input_tensors()
    output_tensors = runner.get_output_tensors()
    
    input_height, input_width = input_tensors[0].dims[1], input_tensors[0].dims[2]
    
  
    preprocessed_image = preprocess_image(image_rgb, (input_height, input_width))
    
    print("Running inference on DPU...")
    input_data = [preprocessed_image]
    output_data = [np.empty(tuple(t.dims), dtype=np.float32) for t in output_tensors]

    start_time = time.time()
    job_id = runner.execute_async(input_data, output_data)
    runner.wait(job_id)
    end_time = time.time()
    
    raw_outputs = output_data
    
    print(f"Inference complete in {end_time - start_time:.4f} seconds.")
    print("Post-processing with NumPy...")
    post_processor = PostProcessNumpy()
    
    outputs_for_post = [np.transpose(raw_output, (0, 3, 1, 2)) for raw_output in raw_outputs]
    predictions = post_processor(outputs_for_post)
    max_obj_conf = np.max(predictions[..., 4])
    print(f"DEBUG: Maximum object confidence score from model = {max_obj_conf:.4f}")

    conf_threshold = 0.01
    detections = non_max_suppression_numpy(predictions, conf_thres=conf_threshold, iou_thres=0.45)[0]

    if detections is not None and len(detections):
        print(f"Found {len(detections)} objects.")
        scaled_detections = scale_coords_numpy(
            (input_height, input_width), detections[:, :4], original_image.shape[:2]
        ).round()
        
        for i, (*xyxy, conf, cls) in enumerate(detections):
            label = f'Class {int(cls)} {conf:.2f}'
            plot_one_box_numpy(scaled_detections[i], original_image, label=label, color=[0, 0, 255])
    else:
        print("Found 0 objects after filtering.")
            
    output_filename = "output.jpg"
    cv2.imwrite(output_filename, original_image)
    print(f"Output image saved as {output_filename}")

    del runner
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='dpu_yolov5.xmodel', help='Path to the xmodel file')
    parser.add_argument('--image', type=str, default='testnew.jpg', help='Path to the input image')
    args = parser.parse_args()

    run_inference(args.model, args.image)
