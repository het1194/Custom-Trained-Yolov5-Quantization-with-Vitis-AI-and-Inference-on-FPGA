# GENETARED BY NNDCT, DO NOT EDIT!

import torch
import pytorch_nndct as py_nndct
class DetectMultiBackend(torch.nn.Module):
    def __init__(self):
        super(DetectMultiBackend, self).__init__()
        self.module_0 = py_nndct.nn.Input() #DetectMultiBackend::input_0
        self.module_1 = py_nndct.nn.Conv2d(in_channels=3, out_channels=32, kernel_size=[6, 6], stride=[2, 2], padding=[2, 2], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[0]/Conv2d[conv]/input.2
        self.module_3 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[0]/LeakyReLU[act]/input.4
        self.module_4 = py_nndct.nn.Conv2d(in_channels=32, out_channels=64, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[1]/Conv2d[conv]/input.5
        self.module_6 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[1]/LeakyReLU[act]/input.7
        self.module_7 = py_nndct.nn.Conv2d(in_channels=64, out_channels=32, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv1]/Conv2d[conv]/input.8
        self.module_9 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv1]/LeakyReLU[act]/input.10
        self.module_10 = py_nndct.nn.Conv2d(in_channels=32, out_channels=32, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.11
        self.module_12 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.13
        self.module_13 = py_nndct.nn.Conv2d(in_channels=32, out_channels=32, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.14
        self.module_15 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/11012
        self.module_16 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Sequential[m]/Bottleneck[0]/11014
        self.module_17 = py_nndct.nn.Conv2d(in_channels=64, out_channels=32, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv2]/Conv2d[conv]/input.16
        self.module_19 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv2]/LeakyReLU[act]/11041
        self.module_20 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/input.18
        self.module_21 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv3]/Conv2d[conv]/input.19
        self.module_23 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[2]/Conv[cv3]/LeakyReLU[act]/input.21
        self.module_24 = py_nndct.nn.Conv2d(in_channels=64, out_channels=128, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[3]/Conv2d[conv]/input.22
        self.module_26 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[3]/LeakyReLU[act]/input.24
        self.module_27 = py_nndct.nn.Conv2d(in_channels=128, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv1]/Conv2d[conv]/input.25
        self.module_29 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv1]/LeakyReLU[act]/input.27
        self.module_30 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.28
        self.module_32 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.30
        self.module_33 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.31
        self.module_35 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/11179
        self.module_36 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[0]/input.33
        self.module_37 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[1]/Conv[cv1]/Conv2d[conv]/input.34
        self.module_39 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[1]/Conv[cv1]/LeakyReLU[act]/input.36
        self.module_40 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[1]/Conv[cv2]/Conv2d[conv]/input.37
        self.module_42 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[1]/Conv[cv2]/LeakyReLU[act]/11235
        self.module_43 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Sequential[m]/Bottleneck[1]/11237
        self.module_44 = py_nndct.nn.Conv2d(in_channels=128, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv2]/Conv2d[conv]/input.39
        self.module_46 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv2]/LeakyReLU[act]/11264
        self.module_47 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/input.41
        self.module_48 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv3]/Conv2d[conv]/input.42
        self.module_50 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[4]/Conv[cv3]/LeakyReLU[act]/input.44
        self.module_51 = py_nndct.nn.Conv2d(in_channels=128, out_channels=256, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[5]/Conv2d[conv]/input.45
        self.module_53 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[5]/LeakyReLU[act]/input.47
        self.module_54 = py_nndct.nn.Conv2d(in_channels=256, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv1]/Conv2d[conv]/input.48
        self.module_56 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv1]/LeakyReLU[act]/input.50
        self.module_57 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.51
        self.module_59 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.53
        self.module_60 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.54
        self.module_62 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/11402
        self.module_63 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[0]/input.56
        self.module_64 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[1]/Conv[cv1]/Conv2d[conv]/input.57
        self.module_66 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[1]/Conv[cv1]/LeakyReLU[act]/input.59
        self.module_67 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[1]/Conv[cv2]/Conv2d[conv]/input.60
        self.module_69 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[1]/Conv[cv2]/LeakyReLU[act]/11458
        self.module_70 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[1]/input.62
        self.module_71 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[2]/Conv[cv1]/Conv2d[conv]/input.63
        self.module_73 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[2]/Conv[cv1]/LeakyReLU[act]/input.65
        self.module_74 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[2]/Conv[cv2]/Conv2d[conv]/input.66
        self.module_76 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[2]/Conv[cv2]/LeakyReLU[act]/11514
        self.module_77 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Sequential[m]/Bottleneck[2]/11516
        self.module_78 = py_nndct.nn.Conv2d(in_channels=256, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv2]/Conv2d[conv]/input.68
        self.module_80 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv2]/LeakyReLU[act]/11543
        self.module_81 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/input.70
        self.module_82 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv3]/Conv2d[conv]/input.71
        self.module_84 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[6]/Conv[cv3]/LeakyReLU[act]/input.73
        self.module_85 = py_nndct.nn.Conv2d(in_channels=256, out_channels=512, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[7]/Conv2d[conv]/input.74
        self.module_87 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[7]/LeakyReLU[act]/input.76
        self.module_88 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv1]/Conv2d[conv]/input.77
        self.module_90 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv1]/LeakyReLU[act]/input.79
        self.module_91 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.80
        self.module_93 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.82
        self.module_94 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.83
        self.module_96 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/11681
        self.module_97 = py_nndct.nn.Add() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Sequential[m]/Bottleneck[0]/11683
        self.module_98 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv2]/Conv2d[conv]/input.85
        self.module_100 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv2]/LeakyReLU[act]/11710
        self.module_101 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/input.87
        self.module_102 = py_nndct.nn.Conv2d(in_channels=512, out_channels=512, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv3]/Conv2d[conv]/input.88
        self.module_104 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[8]/Conv[cv3]/LeakyReLU[act]/input.90
        self.module_105 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/Conv[cv1]/Conv2d[conv]/input.91
        self.module_107 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/Conv[cv1]/LeakyReLU[act]/11767
        self.module_108 = py_nndct.nn.MaxPool2d(kernel_size=[5, 5], stride=[1, 1], padding=[2, 2], dilation=[1, 1], ceil_mode=False) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/MaxPool2d[m]/11781
        self.module_109 = py_nndct.nn.MaxPool2d(kernel_size=[5, 5], stride=[1, 1], padding=[2, 2], dilation=[1, 1], ceil_mode=False) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/MaxPool2d[m]/11795
        self.module_110 = py_nndct.nn.MaxPool2d(kernel_size=[5, 5], stride=[1, 1], padding=[2, 2], dilation=[1, 1], ceil_mode=False) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/MaxPool2d[m]/11809
        self.module_111 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/input.93
        self.module_112 = py_nndct.nn.Conv2d(in_channels=1024, out_channels=512, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/Conv[cv2]/Conv2d[conv]/input.94
        self.module_114 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/SPPF[model]/SPPF[9]/Conv[cv2]/LeakyReLU[act]/input.96
        self.module_115 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[10]/Conv2d[conv]/input.97
        self.module_117 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[10]/LeakyReLU[act]/input.99
        self.module_118 = py_nndct.nn.Interpolate() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Upsample[model]/Upsample[11]/11871
        self.module_119 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Concat[model]/Concat[12]/input.100
        self.module_120 = py_nndct.nn.Conv2d(in_channels=512, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv1]/Conv2d[conv]/input.101
        self.module_122 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv1]/LeakyReLU[act]/input.103
        self.module_123 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.104
        self.module_125 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.106
        self.module_126 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.107
        self.module_128 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/11955
        self.module_129 = py_nndct.nn.Conv2d(in_channels=512, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv2]/Conv2d[conv]/input.109
        self.module_131 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv2]/LeakyReLU[act]/11982
        self.module_132 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/input.111
        self.module_133 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv3]/Conv2d[conv]/input.112
        self.module_135 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[13]/Conv[cv3]/LeakyReLU[act]/input.114
        self.module_136 = py_nndct.nn.Conv2d(in_channels=256, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[14]/Conv2d[conv]/input.115
        self.module_138 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[14]/LeakyReLU[act]/input.117
        self.module_139 = py_nndct.nn.Interpolate() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Upsample[model]/Upsample[15]/12044
        self.module_140 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Concat[model]/Concat[16]/input.118
        self.module_141 = py_nndct.nn.Conv2d(in_channels=256, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv1]/Conv2d[conv]/input.119
        self.module_143 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv1]/LeakyReLU[act]/input.121
        self.module_144 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.122
        self.module_146 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.124
        self.module_147 = py_nndct.nn.Conv2d(in_channels=64, out_channels=64, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.125
        self.module_149 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/12128
        self.module_150 = py_nndct.nn.Conv2d(in_channels=256, out_channels=64, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv2]/Conv2d[conv]/input.127
        self.module_152 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv2]/LeakyReLU[act]/12155
        self.module_153 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/input.129
        self.module_154 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv3]/Conv2d[conv]/input.130
        self.module_156 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[17]/Conv[cv3]/LeakyReLU[act]/input.132
        self.module_157 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[18]/Conv2d[conv]/input.133
        self.module_159 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[18]/LeakyReLU[act]/12212
        self.module_160 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Concat[model]/Concat[19]/input.135
        self.module_161 = py_nndct.nn.Conv2d(in_channels=256, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv1]/Conv2d[conv]/input.136
        self.module_163 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv1]/LeakyReLU[act]/input.138
        self.module_164 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.139
        self.module_166 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.141
        self.module_167 = py_nndct.nn.Conv2d(in_channels=128, out_channels=128, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.142
        self.module_169 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/12296
        self.module_170 = py_nndct.nn.Conv2d(in_channels=256, out_channels=128, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv2]/Conv2d[conv]/input.144
        self.module_172 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv2]/LeakyReLU[act]/12323
        self.module_173 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/input.146
        self.module_174 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv3]/Conv2d[conv]/input.147
        self.module_176 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[20]/Conv[cv3]/LeakyReLU[act]/input.149
        self.module_177 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[3, 3], stride=[2, 2], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[21]/Conv2d[conv]/input.150
        self.module_179 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Conv[model]/Conv[21]/LeakyReLU[act]/12380
        self.module_180 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Concat[model]/Concat[22]/input.152
        self.module_181 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv1]/Conv2d[conv]/input.153
        self.module_183 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv1]/LeakyReLU[act]/input.155
        self.module_184 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Sequential[m]/Bottleneck[0]/Conv[cv1]/Conv2d[conv]/input.156
        self.module_186 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Sequential[m]/Bottleneck[0]/Conv[cv1]/LeakyReLU[act]/input.158
        self.module_187 = py_nndct.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=[3, 3], stride=[1, 1], padding=[1, 1], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Sequential[m]/Bottleneck[0]/Conv[cv2]/Conv2d[conv]/input.159
        self.module_189 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Sequential[m]/Bottleneck[0]/Conv[cv2]/LeakyReLU[act]/12464
        self.module_190 = py_nndct.nn.Conv2d(in_channels=512, out_channels=256, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv2]/Conv2d[conv]/input.161
        self.module_192 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv2]/LeakyReLU[act]/12491
        self.module_193 = py_nndct.nn.Cat() #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/input.163
        self.module_194 = py_nndct.nn.Conv2d(in_channels=512, out_channels=512, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv3]/Conv2d[conv]/input.164
        self.module_196 = py_nndct.nn.LeakyReLU(negative_slope=0.1015625, inplace=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/C3[model]/C3[23]/Conv[cv3]/LeakyReLU[act]/input
        self.module_197 = py_nndct.nn.Conv2d(in_channels=128, out_channels=18, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/Conv2d[m]/ModuleList[0]/12540
        self.module_198 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12542
        self.module_199 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12549
        self.module_200 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12553
        self.module_201 = py_nndct.nn.Module('reshape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12559
        self.module_202 = py_nndct.nn.Module('permute') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12566
        self.module_203 = py_nndct.nn.Module('contiguous') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12568
        self.module_204 = py_nndct.nn.Conv2d(in_channels=256, out_channels=18, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/Conv2d[m]/ModuleList[1]/12587
        self.module_205 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12589
        self.module_206 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12596
        self.module_207 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12600
        self.module_208 = py_nndct.nn.Module('reshape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12606
        self.module_209 = py_nndct.nn.Module('permute') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12613
        self.module_210 = py_nndct.nn.Module('contiguous') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12615
        self.module_211 = py_nndct.nn.Conv2d(in_channels=512, out_channels=18, kernel_size=[1, 1], stride=[1, 1], padding=[0, 0], dilation=[1, 1], groups=1, bias=True) #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/Conv2d[m]/ModuleList[2]/12634
        self.module_212 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12636
        self.module_213 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12643
        self.module_214 = py_nndct.nn.Module('shape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12647
        self.module_215 = py_nndct.nn.Module('reshape') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12653
        self.module_216 = py_nndct.nn.Module('permute') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12660
        self.module_217 = py_nndct.nn.Module('contiguous') #DetectMultiBackend::DetectMultiBackend/DetectionModel[model]/Detect[model]/Detect[24]/12662

    def forward(self, *args):
        output_module_0 = self.module_0(input=args[0])
        output_module_0 = self.module_1(output_module_0)
        output_module_0 = self.module_3(output_module_0)
        output_module_0 = self.module_4(output_module_0)
        output_module_0 = self.module_6(output_module_0)
        output_module_7 = self.module_7(output_module_0)
        output_module_7 = self.module_9(output_module_7)
        output_module_10 = self.module_10(output_module_7)
        output_module_10 = self.module_12(output_module_10)
        output_module_10 = self.module_13(output_module_10)
        output_module_10 = self.module_15(output_module_10)
        output_module_16 = self.module_16(input=output_module_7, other=output_module_10, alpha=1)
        output_module_17 = self.module_17(output_module_0)
        output_module_17 = self.module_19(output_module_17)
        output_module_16 = self.module_20(dim=1, tensors=[output_module_16,output_module_17])
        output_module_16 = self.module_21(output_module_16)
        output_module_16 = self.module_23(output_module_16)
        output_module_16 = self.module_24(output_module_16)
        output_module_16 = self.module_26(output_module_16)
        output_module_27 = self.module_27(output_module_16)
        output_module_27 = self.module_29(output_module_27)
        output_module_30 = self.module_30(output_module_27)
        output_module_30 = self.module_32(output_module_30)
        output_module_30 = self.module_33(output_module_30)
        output_module_30 = self.module_35(output_module_30)
        output_module_36 = self.module_36(input=output_module_27, other=output_module_30, alpha=1)
        output_module_37 = self.module_37(output_module_36)
        output_module_37 = self.module_39(output_module_37)
        output_module_37 = self.module_40(output_module_37)
        output_module_37 = self.module_42(output_module_37)
        output_module_43 = self.module_43(input=output_module_36, other=output_module_37, alpha=1)
        output_module_44 = self.module_44(output_module_16)
        output_module_44 = self.module_46(output_module_44)
        output_module_43 = self.module_47(dim=1, tensors=[output_module_43,output_module_44])
        output_module_43 = self.module_48(output_module_43)
        output_module_43 = self.module_50(output_module_43)
        output_module_51 = self.module_51(output_module_43)
        output_module_51 = self.module_53(output_module_51)
        output_module_54 = self.module_54(output_module_51)
        output_module_54 = self.module_56(output_module_54)
        output_module_57 = self.module_57(output_module_54)
        output_module_57 = self.module_59(output_module_57)
        output_module_57 = self.module_60(output_module_57)
        output_module_57 = self.module_62(output_module_57)
        output_module_63 = self.module_63(input=output_module_54, other=output_module_57, alpha=1)
        output_module_64 = self.module_64(output_module_63)
        output_module_64 = self.module_66(output_module_64)
        output_module_64 = self.module_67(output_module_64)
        output_module_64 = self.module_69(output_module_64)
        output_module_70 = self.module_70(input=output_module_63, other=output_module_64, alpha=1)
        output_module_71 = self.module_71(output_module_70)
        output_module_71 = self.module_73(output_module_71)
        output_module_71 = self.module_74(output_module_71)
        output_module_71 = self.module_76(output_module_71)
        output_module_77 = self.module_77(input=output_module_70, other=output_module_71, alpha=1)
        output_module_78 = self.module_78(output_module_51)
        output_module_78 = self.module_80(output_module_78)
        output_module_77 = self.module_81(dim=1, tensors=[output_module_77,output_module_78])
        output_module_77 = self.module_82(output_module_77)
        output_module_77 = self.module_84(output_module_77)
        output_module_85 = self.module_85(output_module_77)
        output_module_85 = self.module_87(output_module_85)
        output_module_88 = self.module_88(output_module_85)
        output_module_88 = self.module_90(output_module_88)
        output_module_91 = self.module_91(output_module_88)
        output_module_91 = self.module_93(output_module_91)
        output_module_91 = self.module_94(output_module_91)
        output_module_91 = self.module_96(output_module_91)
        output_module_97 = self.module_97(input=output_module_88, other=output_module_91, alpha=1)
        output_module_98 = self.module_98(output_module_85)
        output_module_98 = self.module_100(output_module_98)
        output_module_97 = self.module_101(dim=1, tensors=[output_module_97,output_module_98])
        output_module_97 = self.module_102(output_module_97)
        output_module_97 = self.module_104(output_module_97)
        output_module_97 = self.module_105(output_module_97)
        output_module_97 = self.module_107(output_module_97)
        output_module_108 = self.module_108(output_module_97)
        output_module_109 = self.module_109(output_module_108)
        output_module_110 = self.module_110(output_module_109)
        output_module_111 = self.module_111(dim=1, tensors=[output_module_97,output_module_108,output_module_109,output_module_110])
        output_module_111 = self.module_112(output_module_111)
        output_module_111 = self.module_114(output_module_111)
        output_module_111 = self.module_115(output_module_111)
        output_module_111 = self.module_117(output_module_111)
        output_module_118 = self.module_118(input=output_module_111, size=None, scale_factor=[2.0,2.0], mode='nearest')
        output_module_118 = self.module_119(dim=1, tensors=[output_module_118,output_module_77])
        output_module_120 = self.module_120(output_module_118)
        output_module_120 = self.module_122(output_module_120)
        output_module_120 = self.module_123(output_module_120)
        output_module_120 = self.module_125(output_module_120)
        output_module_120 = self.module_126(output_module_120)
        output_module_120 = self.module_128(output_module_120)
        output_module_129 = self.module_129(output_module_118)
        output_module_129 = self.module_131(output_module_129)
        output_module_120 = self.module_132(dim=1, tensors=[output_module_120,output_module_129])
        output_module_120 = self.module_133(output_module_120)
        output_module_120 = self.module_135(output_module_120)
        output_module_120 = self.module_136(output_module_120)
        output_module_120 = self.module_138(output_module_120)
        output_module_139 = self.module_139(input=output_module_120, size=None, scale_factor=[2.0,2.0], mode='nearest')
        output_module_139 = self.module_140(dim=1, tensors=[output_module_139,output_module_43])
        output_module_141 = self.module_141(output_module_139)
        output_module_141 = self.module_143(output_module_141)
        output_module_141 = self.module_144(output_module_141)
        output_module_141 = self.module_146(output_module_141)
        output_module_141 = self.module_147(output_module_141)
        output_module_141 = self.module_149(output_module_141)
        output_module_150 = self.module_150(output_module_139)
        output_module_150 = self.module_152(output_module_150)
        output_module_141 = self.module_153(dim=1, tensors=[output_module_141,output_module_150])
        output_module_141 = self.module_154(output_module_141)
        output_module_141 = self.module_156(output_module_141)
        output_module_157 = self.module_157(output_module_141)
        output_module_157 = self.module_159(output_module_157)
        output_module_157 = self.module_160(dim=1, tensors=[output_module_157,output_module_120])
        output_module_161 = self.module_161(output_module_157)
        output_module_161 = self.module_163(output_module_161)
        output_module_161 = self.module_164(output_module_161)
        output_module_161 = self.module_166(output_module_161)
        output_module_161 = self.module_167(output_module_161)
        output_module_161 = self.module_169(output_module_161)
        output_module_170 = self.module_170(output_module_157)
        output_module_170 = self.module_172(output_module_170)
        output_module_161 = self.module_173(dim=1, tensors=[output_module_161,output_module_170])
        output_module_161 = self.module_174(output_module_161)
        output_module_161 = self.module_176(output_module_161)
        output_module_177 = self.module_177(output_module_161)
        output_module_177 = self.module_179(output_module_177)
        output_module_177 = self.module_180(dim=1, tensors=[output_module_177,output_module_111])
        output_module_181 = self.module_181(output_module_177)
        output_module_181 = self.module_183(output_module_181)
        output_module_181 = self.module_184(output_module_181)
        output_module_181 = self.module_186(output_module_181)
        output_module_181 = self.module_187(output_module_181)
        output_module_181 = self.module_189(output_module_181)
        output_module_190 = self.module_190(output_module_177)
        output_module_190 = self.module_192(output_module_190)
        output_module_181 = self.module_193(dim=1, tensors=[output_module_181,output_module_190])
        output_module_181 = self.module_194(output_module_181)
        output_module_181 = self.module_196(output_module_181)
        output_module_197 = self.module_197(output_module_141)
        output_module_198 = self.module_198(input=output_module_197, dim=0)
        output_module_199 = self.module_199(input=output_module_197, dim=2)
        output_module_200 = self.module_200(input=output_module_197, dim=3)
        output_module_201 = self.module_201(input=output_module_197, shape=[output_module_198,3,6,output_module_199,output_module_200])
        output_module_201 = self.module_202(dims=[0,1,3,4,2], input=output_module_201)
        output_module_201 = self.module_203(output_module_201)
        output_module_204 = self.module_204(output_module_161)
        output_module_205 = self.module_205(input=output_module_204, dim=0)
        output_module_206 = self.module_206(input=output_module_204, dim=2)
        output_module_207 = self.module_207(input=output_module_204, dim=3)
        output_module_208 = self.module_208(input=output_module_204, shape=[output_module_205,3,6,output_module_206,output_module_207])
        output_module_208 = self.module_209(dims=[0,1,3,4,2], input=output_module_208)
        output_module_208 = self.module_210(output_module_208)
        output_module_181 = self.module_211(output_module_181)
        output_module_212 = self.module_212(input=output_module_181, dim=0)
        output_module_213 = self.module_213(input=output_module_181, dim=2)
        output_module_214 = self.module_214(input=output_module_181, dim=3)
        output_module_215 = self.module_215(input=output_module_181, shape=[output_module_212,3,6,output_module_213,output_module_214])
        output_module_215 = self.module_216(dims=[0,1,3,4,2], input=output_module_215)
        output_module_215 = self.module_217(output_module_215)
        return output_module_201,output_module_208,output_module_215
