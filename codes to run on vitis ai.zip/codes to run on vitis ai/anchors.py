import torch

# Load the trained model
model = torch.load('best.pt', map_location='cpu')

# Access anchors
anchors = model['model'].model[-1].anchors  # Detect layer is usually last
print("Anchors from trained model:")
print(anchors)

"""
OUTPUT

Anchors from trained model:
tensor([[[ 1.25000,  1.62500],
         [ 2.00000,  3.75000],
         [ 4.12500,  2.87500]],

        [[ 1.87500,  3.81250],
         [ 3.87500,  2.81250],
         [ 3.68750,  7.43750]],

        [[ 3.62500,  2.81250],
         [ 4.87500,  6.18750],
         [11.65625, 10.18750]]], dtype=torch.float16)
(vitis-ai-pytorch) Vitis-AI /workspace/yolov5_fire > 


"""
