import os
import sys
import argparse
import torch
from torch.utils.data import Dataset
import torchvision
from torchvision.io import read_image
from pytorch_nndct.apis import torch_quantizer
from models.common import DetectMultiBackend

class CustomImageDataset(Dataset):
    def __init__(self, label_dir, img_dir, width, height):
        self.label_dir = label_dir
        self.img_dir = img_dir
        self.width = width
        self.height = height
        self.img_names = [os.path.splitext(f)[0] for f in os.listdir(img_dir)]

    def __len__(self):
        return len(self.img_names)

    def __getitem__(self, idx):
        img_name = self.img_names[idx]
        img_path = os.path.join(self.img_dir, img_name + ".jpg")
        label_path = os.path.join(self.label_dir, img_name + ".txt")

        image = read_image(img_path).float() / 255.0
        image = torchvision.transforms.Resize((self.width, self.height))(image)

        boxes, labels = [], []
        with open(label_path) as f:
            for line in f.readlines():
                vals = line.strip().split()
                labels.append(int(vals[0]))
                x0 = (float(vals[1]) - float(vals[3]) / 2) * self.width
                y0 = (float(vals[2]) - float(vals[4]) / 2) * self.height
                x1 = (float(vals[1]) + float(vals[3]) / 2) * self.width
                y1 = (float(vals[2]) + float(vals[4]) / 2) * self.height
                boxes.append([x0, y0, x1, y1])

        target = {
            "boxes": torch.tensor(boxes, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.int64),
            "image_id": torch.tensor([idx + 1])
        }
        return image, target

def quantize(build_dir, quant_mode, weights, dataset_dir):
    quant_model_dir = os.path.join(build_dir, 'quant_model')
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load model
    model = DetectMultiBackend(weights=weights).to(device)
    rand_input = torch.randn(1, 3, 640, 640).to(device)

    # quantizer
    quantizer = torch_quantizer(quant_mode, model, rand_input, output_dir=quant_model_dir)
    quantized_model = quantizer.quant_model.to(device)

    # Dataset 
    dataset = CustomImageDataset(
        os.path.join(dataset_dir, 'labels'),
        os.path.join(dataset_dir, 'images'),
        width=640, height=640
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    quantized_model.eval()
    with torch.no_grad():
        for img, target in loader:
            _ = quantized_model(img.to(device))  # raw outputs only

    if quant_mode == 'calib':
        quantizer.export_quant_config()
    elif quant_mode == 'test':
        quantizer.export_xmodel(deploy_check=False, output_dir=quant_model_dir)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--build_dir', type=str, default='build')
    parser.add_argument('-q', '--quant_mode', type=str, default='calib', choices=['calib','test'])
    parser.add_argument('-w', '--weights', type=str, required=True)
    parser.add_argument('-d', '--dataset', type=str, required=True)
    args = parser.parse_args()

    quantize(args.build_dir, args.quant_mode, args.weights, args.dataset)

if __name__ == '__main__':
    main()
