import os
import shutil

train_images_dir = "./Fire-Dettection-2/train/images"
train_labels_dir = "./Fire-Dettection-2/train/labels"
calib_images_dir = "./calib_dataset/images"
calib_labels_dir = "./calib_dataset/labels"

os.makedirs(calib_images_dir, exist_ok=True)
os.makedirs(calib_labels_dir, exist_ok=True)
all_images = sorted([f for f in os.listdir(train_images_dir) if f.endswith(".jpg")])
selected_images = all_images[:50]

for img_file in selected_images:
    # Source 
    src_img = os.path.join(train_images_dir, img_file)
    src_label = os.path.join(train_labels_dir, img_file.replace(".jpg", ".txt"))

    # Destination
    dst_img = os.path.join(calib_images_dir, img_file)
    dst_label = os.path.join(calib_labels_dir, img_file.replace(".jpg", ".txt"))


    shutil.copy(src_img, dst_img)
    if os.path.exists(src_label):
        shutil.copy(src_label, dst_label)
    else:
        print(f"Label missing for image: {img_file}")

print(f"Copied {len(selected_images)} images and their labels to calib_dataset.")
