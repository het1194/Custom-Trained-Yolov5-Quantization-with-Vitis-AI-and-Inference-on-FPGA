import torch
import torch.nn as nn
from utils.general import check_version

class Post_Process(nn.Module):
    def __init__(self):
        super().__init__()
        self.nc = 1  
        self.no = self.nc + 5 
        
        anchors = [
            [1.25, 1.625, 2.0, 3.75, 4.125, 2.875],
            [1.875, 3.8125, 3.875, 2.8125, 3.6875, 7.4375],
            [3.625, 2.8125, 4.875, 6.1875, 11.65625, 10.1875]
        ]

        self.nl = len(anchors)  
        self.na = len(anchors[0]) // 2  
        self.grid = [torch.zeros(1)] * self.nl
        self.anchor_grid = [torch.zeros(1)] * self.nl

        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))
        self.stride = torch.tensor([8., 16., 32.]) 

    def _make_grid(self, nx=20, ny=20, i=0):
        d = self.anchors[i].device
        t = self.anchors[i].dtype
        shape = (1, self.na, ny, nx, 2)
        y, x = torch.arange(ny, device=d, dtype=t), torch.arange(nx, device=d, dtype=t)
        yv, xv = torch.meshgrid(y, x, indexing='ij')
        grid = torch.stack((xv, yv), 2).expand(shape)
        anchor_grid = (self.anchors[i] * self.stride[i]).view((1, self.na, 1, 1, 2)).expand(shape)
        return grid, anchor_grid

    def method(self, x):  
        z = [] 
        for i in range(self.nl):
            bs, _, ny, nx, _ = x[i].shape
            if self.grid[i].shape[2:4] != x[i].shape[2:4]:
                self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

            y = x[i].sigmoid()
            y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
            y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
            z.append(y.view(bs, -1, self.no))

        return torch.cat(z, 1), x

